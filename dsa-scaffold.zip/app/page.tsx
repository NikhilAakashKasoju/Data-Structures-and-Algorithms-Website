import { COURSE } from "@/lib/course";

/**
 * Scaffold placeholder.
 *
 * This page exists only to prove the design system renders — fonts, tokens,
 * background layers, both themes, the button/card/panel primitives. Every
 * real section (Nav, Hero, Marquee, Curriculum, …) replaces it one at a time.
 *
 * Server component: nothing here needs a hook.
 */
export default function Page() {
  return (
    <section
      id="scaffold"
      className="relative z-10 mx-auto max-w-[1300px] px-5 py-20 sm:px-8 sm:py-28 lg:px-12"
    >
      <p className="eyebrow">/ Design system check</p>

      <h1 className="mt-4 font-display text-[clamp(40px,5vw,72px)] font-bold leading-[1.04] tracking-tight">
        {COURSE.title}
      </h1>

      <p className="mt-5 max-w-[62ch] text-[16.5px] leading-relaxed text-muted">
        Scaffold only. Tokens, fonts, background layers and the reduced-motion
        stack are wired; no content sections exist yet.
      </p>

      <div className="mt-8 flex flex-wrap gap-3">
        <a className="btn-primary" href={COURSE.udemyUrl} target="_blank" rel="noopener noreferrer">
          View on Udemy
        </a>
        <a className="btn-secondary" href="#scaffold">
          Secondary action
        </a>
      </div>

      {/* Stat pairs are a <dl>: plain divs make a screen reader read
          "21 Sections 222 Lectures" as one undifferentiated run. */}
      <dl className="mt-12 grid grid-cols-2 gap-4 sm:grid-cols-3">
        <Stat label="Sections" value={String(COURSE.sections)} />
        <Stat label="Lectures" value={String(COURSE.lectures)} />
        <Stat
          label="Runtime"
          value={`${COURSE.runtimeHours}h ${COURSE.runtimeMinutes}m`}
        />
      </dl>

      <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {COURSE.verifiedSections.slice(0, 3).map((s) => (
          <div key={s} className="card">
            <h2 className="font-display text-[19px] font-semibold leading-snug">{s}</h2>
            <p className="mt-2 text-[15.5px] leading-relaxed text-muted">
              Verified section title from the Udemy curriculum.
            </p>
          </div>
        ))}
      </div>

      <div className="relative mt-12">
        {/* Halo as a blurred sibling, not a box-shadow — a shadow this large
            and diffuse shows visible colour banding on #0d0714. */}
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -inset-6 -z-10 rounded-[40px] bg-purple/20 blur-3xl"
        />
        <div className="panel">
          <p className="label">Raised panel</p>
          <p className="mt-3 text-[16.5px] leading-relaxed text-muted">
            Translucent wash over the page gradient, never a solid fill.
          </p>
        </div>
      </div>
    </section>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-line bg-surface p-5">
      <dt className="label">{label}</dt>
      <dd className="mt-1 font-display text-[34px] font-bold leading-none tabular">
        {value}
      </dd>
    </div>
  );
}
