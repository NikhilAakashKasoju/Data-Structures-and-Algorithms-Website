# EduFulness — Data Structures & Algorithms

Marketing site for the DSA course, modelled on `edufulness.com/data-engineering`.

Next.js 14 (App Router) · TypeScript · Tailwind · Framer Motion · static export.

---

## Run

```bash
npm install
npm run dev        # http://localhost:3000/dsa
npm run build      # emits ./out
npm run typecheck
```

`npm run build` needs network access on first run: `next/font/google` downloads
the three font families and self-hosts them into the export. After that the
files are cached in `.next/cache`.

## Deploy

1. `npm run build`
2. **Delete everything inside** `public_html/dsa/` first — `_next/` filenames are
   content-hashed, so stale chunks accumulate forever otherwise.
3. Upload the contents of `out/` into `public_html/dsa/`.

The host is Hostinger shared hosting: PHP only, no Node runtime. Anything
server-side (contact form) will be a small PHP endpoint in its own folder, not
an `app/api/**` route handler — route handlers do not exist under
`output: "export"`.

## Architecture notes

| File | Why it exists |
| --- | --- |
| `next.config.mjs` | `output: "export"`, `basePath: "/dsa"`, `trailingSlash`, unoptimized images |
| `lib/site.ts` | `asset()` — every `public/` path must go through it or it 404s in production |
| `lib/motion.ts` | Shared entrance variants so the whole page animates as one document |
| `lib/course.ts` | Single source of truth for course facts; unverified values are `null` |
| `app/globals.css` | Theme tokens, background layers, component primitives, reduced-motion layer 1 |
| `components/ThemeScript.tsx` | Blocking inline script — sets `data-theme` before first paint, no flash |
| `components/MotionProvider.tsx` | `MotionConfig reducedMotion="user"` — reduced-motion layer 2 |
| `components/ThemeToggle.tsx` | Fixed bottom-right switch, 44×44 hit area, `aria-pressed` |

### Reduced motion is three separate layers

1. `@media (prefers-reduced-motion: reduce)` in `globals.css` → CSS animations/transitions
2. `<MotionConfig reducedMotion="user">` → Framer's JS-driven transforms, which CSS cannot reach
3. `svgRef.current.pauseAnimations()` per illustration → SVG SMIL (`<animateMotion>`), which
   neither of the above reaches

Layer 3 lands with the first illustration.

### Colour

All colour resolves through CSS variables on `<html data-theme>`. **No component
carries a `dark:` class.** Palette tokens are channel triplets (`13 7 20`) so
Tailwind's `<alpha-value>` still works (`bg-bg/70`); `surface`/`line`/`chip`/
`faint` hold full `rgba()` because their alpha differs per theme.

Do not use `purple` (`#0b4fdb`) for small text on dark — it fails contrast. Use
`purple-2`.

---

## Verified facts

Source: the Udemy listing supplied by the client, fetched 2026-08-18 —
<https://www.udemy.com/course/mastering-data-structures-and-algorithms-using-c-programming/>

- Title: *Data Structures & Algorithms using C++, C and Python - 2026*
- Instructor: Atchyut Kumar · Publisher: Edufulness EFN
- 21 sections · 222 lectures · 43h 57m
- Languages: C, C++, Python
- Section titles 1–10 (see `lib/course.ts`)
- "What you'll learn" bullets, quoted verbatim

## Known Gaps

Nothing below is invented anywhere in the codebase. Each is `null` in
`lib/course.ts` and will render as a flagged placeholder until supplied.

| # | Gap | Blocks |
| --- | --- | --- |
| 1 | **Section titles 11–21.** Udemy lazy-loads the rest of the curriculum; only 1–10 were returned. | Curriculum, Phases |
| 2 | **Phase grouping.** How the 21 sections map onto the "phases" grid used on the DE site. | Phases |
| 3 | **Programme price + checkout URL** for direct EduFulness enrolment (not the Udemy listing). | Program, Hero CTA |
| 4 | **Batch structure** — weekday/weekend, programme length in months, weekly hours. | Program |
| 5 | **Next live class** — date, topic, duration, time. Needs a "nothing scheduled" state either way. | LiveClass |
| 6 | **Free resources** — YouTube playlist URLs and video counts for DSA (the DE numbers do not transfer). | Resources |
| 7 | **Contact** — WhatsApp community link, reply-to email, PHP form endpoint path. | Contact, Footer |
| 8 | **Instructor copy for DSA.** The DE site's bio (M.Tech NIT Calicut, GATE AIR 440, 110,000+ students mentored) is on record for Atchyut but should be confirmed before reuse here. | Instructor |
| 9 | **Icons** — `app/icon.png` (512×512), `app/apple-icon.png` (180×180), `app/opengraph-image.png` (1200×630, PNG/JPEG — not WebP). | Metadata |
| 10 | **Prerequisites / target audience wording** and any certificate claim. Do not assert a certificate unless the client confirms one exists. | Hero, Program |

## Build order

Nav → Hero → Marquee → Curriculum → Phases → Resources → LiveClass → Program →
Instructor → Contact → Footer. One section per pass.
